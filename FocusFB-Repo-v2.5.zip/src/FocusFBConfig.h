#pragma once

// Versione di FocusFB mostrata nelle impostazioni
#define FOCUSFB_VERSION_STRING @"2.5"

// Link del progetto mostrati nella sezione "Info" delle impostazioni.
// Modifica FOCUSFB_PAYPAL_URL con il tuo link PayPal.me personale (o lascialo vuoto @"" per nascondere la voce).
#define FOCUSFB_PAYPAL_URL     @"https://paypal.me/Skiliflippo"
#define FOCUSFB_GITHUB_URL     @"https://github.com/Skiliflippo/FocusFB"
