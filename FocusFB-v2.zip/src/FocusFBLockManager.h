#pragma once
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FFBPhysicalKeyType) {
    FFBPhysicalKeyTypeNone        = 0,
    FFBPhysicalKeyTypeBarcodeOrQR = 1,
    FFBPhysicalKeyTypeNFCTag      = 2,
};

extern NSString *const FocusFBLockStateDidChangeNotification;

@interface FocusFBLockManager : NSObject

+ (instancetype)shared;

/// Avvia il monitoraggio al lancio dell'app
- (void)start;

/// Stato Blocco Rigoroso (stile Foqos)
@property (nonatomic, readonly) BOOL strictLockActive;
@property (nonatomic, readonly) FFBPhysicalKeyType keyType;
@property (nonatomic, copy, readonly, nullable) NSString *keyLabel;
@property (nonatomic, readonly) BOOL hasRegisteredKey;

/// Configurazione Limiti di Tempo (modificabili solo quando non bloccato o con sessione sbloccata)
@property (nonatomic, assign) NSInteger sessionLimitMinutes; // 0 = disattivato
@property (nonatomic, assign) NSInteger cooldownMinutes;     // pausa obbligatoria post-sessione (default 30)
@property (nonatomic, assign) NSInteger dailyLimitMinutes;   // 0 = disattivato
@property (nonatomic, assign) BOOL showRemainingTimerPill;

/// Statistiche live della sessione / giornata corrente
@property (nonatomic, readonly) NSInteger sessionUsedSeconds;
@property (nonatomic, readonly) NSInteger dailyUsedSeconds;
@property (nonatomic, readonly) NSTimeInterval cooldownRemainingSeconds;
@property (nonatomic, readonly) NSTimeInterval secondsUntilMidnight;
@property (nonatomic, readonly) BOOL isSessionLockedOut;
@property (nonatomic, readonly) BOOL isDailyLockedOut;
@property (nonatomic, readonly) BOOL isTimeBlockedNow;

/// Stringhe formattate pronte per UI
- (NSString *)formattedRemainingSummary;
- (NSString *)registeredKeyDescription;

/// Attivazione / Disattivazione Blocco Rigoroso
- (BOOL)enableStrictLockError:(NSString * _Nullable * _Nullable)errorOut;
- (void)disableStrictLockAfterVerifiedScan;

/// Registrazione Chiavi Fisiche (chiamabili da UI Impostazioni)
- (void)presentRegisterBarcodeOrQRFrom:(UIViewController *)presenter
                            completion:(void (^ _Nullable)(BOOL success))completion;

- (void)presentGenerateSecretQRFrom:(UIViewController *)presenter
                         completion:(void (^ _Nullable)(BOOL success))completion;

- (void)presentRegisterNFCTagFrom:(UIViewController *)presenter
                       completion:(void (^ _Nullable)(BOOL success))completion;

/// Scansione di verifica della chiave fisica registrata (QR/Barcode o NFC in base a keyType)
- (void)presentVerifyPhysicalKeyFrom:(UIViewController *)presenter
                              reason:(nullable NSString *)reason
                          completion:(void (^)(BOOL verified))completion;

/// Azioni post-verifica emergenza
- (void)grantEmergencyFiveMinutes;
- (void)resetTodayUsageAndCooldown;

/// Aggiorna subito finestra di blocco e pillola timer
- (void)refreshEnforcementUI;

@end

NS_ASSUME_NONNULL_END
