#import "FocusFBAdBlocker.h"
#import "FocusFBPrefs.h"

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <algorithm>
#include <atomic>

@interface NSObject (FFBGraphQLModelSelectors)
- (nullable id)category;
- (nullable id)sponsoredData;
- (BOOL)isSponsored;
@end

static std::atomic<uint64_t> gBlockedAdsCount{0};
static char kCellHiddenByAdBlockKey;
static char kCellCountedByAdBlockKey;

typedef id (*FFBPandoInitIMP)(id, SEL, void *);
typedef id (*FFBJSONDataIMP)(id, SEL, NSData *, NSJSONReadingOptions, NSError * __autoreleasing *);
typedef void (*FFBVoidIMP)(id, SEL);

static FFBPandoInitIMP gOrigInitWithPandoTree = NULL;
static FFBPandoInitIMP gOrigInitWithFBTree    = NULL;
static FFBJSONDataIMP  gOrigJSONWithData      = NULL;
static FFBVoidIMP      gOrigCellLayout        = NULL;
static FFBVoidIMP      gOrigCellPrepareReuse  = NULL;

static BOOL gInstalledPandoHook    = NO;
static BOOL gInstalledFBTreeHook   = NO;
static BOOL gInstalledJSONHook     = NO;
static BOOL gInstalledCellHooks    = NO;

NSUInteger FocusFBBlockedAdsCount(void) {
    return (NSUInteger)gBlockedAdsCount.load(std::memory_order_relaxed);
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper Runtime Sicuri (Thread-Safe, Zero Overhead NSMethodSignature)
// ─────────────────────────────────────────────────────────────────────────────

static BOOL FFBMethodReturnsObject(Class cls, SEL sel) {
    if (!cls || !sel) return NO;
    Method m = class_getInstanceMethod(cls, sel);
    if (!m) return NO;
    const char *enc = method_getTypeEncoding(m);
    return (enc != NULL && enc[0] == '@');
}

static BOOL FFBMethodReturnsBool(Class cls, SEL sel) {
    if (!cls || !sel) return NO;
    Method m = class_getInstanceMethod(cls, sel);
    if (!m) return NO;
    const char *enc = method_getTypeEncoding(m);
    return (enc != NULL && (enc[0] == 'B' || enc[0] == 'c'));
}

static BOOL FFBInstallMethodHook(Class cls, SEL sel, IMP newIMP, IMP *origOut) {
    if (!cls || !sel || !newIMP) return NO;
    Method resolved = class_getInstanceMethod(cls, sel);
    if (!resolved) return NO;
    IMP orig = method_getImplementation(resolved);
    const char *types = method_getTypeEncoding(resolved);
    if (!orig || !types || orig == newIMP) return NO;

    if (origOut && *origOut == NULL) {
        *origOut = orig;
    }

    unsigned int count = 0;
    Method *directList = class_copyMethodList(cls, &count);
    BOOL hasDirect = NO;
    for (unsigned int i = 0; i < count; i++) {
        if (method_getName(directList[i]) == sel) {
            hasDirect = YES;
            break;
        }
    }
    free(directList);

    if (hasDirect) {
        class_replaceMethod(cls, sel, newIMP, types);
    } else {
        if (!class_addMethod(cls, sel, newIMP, types)) {
            return NO;
        }
    }
    return YES;
}

// ─────────────────────────────────────────────────────────────────────────────
// LIVELLO 1: Pando & GraphQL Model Layer (FBMemModelObject)
// Rimuove gli annunci prima che raggiungano i dataSource -> ZERO celle vuote
// ─────────────────────────────────────────────────────────────────────────────

static BOOL FFBIsThreadsPromoModel(id model, Class cls) {
    static NSArray<NSString *> *keys = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        keys = @[@"feedUnitType", @"feed_unit_type", @"unitType", @"inlineUnitType"];
    });

    for (NSString *key in keys) {
        SEL sel = NSSelectorFromString(key);
        if (FFBMethodReturnsObject(cls, sel)) {
            @try {
                id val = ((id (*)(id, SEL))objc_msgSend)(model, sel);
                if ([val isKindOfClass:NSString.class] &&
                    ([val isEqualToString:@"THREADS_IN_FEED_UNIT"] ||
                     [val isEqualToString:@"THREADS_IN_STORY_UNIT_MID_CARD"])) {
                    return YES;
                }
            } @catch (__unused NSException *e) {}
        }
        @try {
            id val = [model valueForKey:key];
            if ([val isKindOfClass:NSString.class] &&
                ([val isEqualToString:@"THREADS_IN_FEED_UNIT"] ||
                 [val isEqualToString:@"THREADS_IN_STORY_UNIT_MID_CARD"])) {
                return YES;
            }
        } @catch (__unused NSException *e) {}
    }
    return NO;
}

static BOOL FFBIsMarketplaceModelSponsoredViaKVC(id model) {
    static NSArray<NSString *> *nonNullAdKeys = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        nonNullAdKeys = @[
            @"sponsored_data",
            @"sponsoredData",
            @"ad_data",
            @"adData",
            @"boosted_marketplace_listing",
            @"promoted_listing_info",
            @"marketplace_ad_data"
        ];
    });

    for (NSString *k in nonNullAdKeys) {
        @try {
            id v = [model valueForKey:k];
            if (v != nil && ![v isKindOfClass:NSNull.class]) {
                return YES;
            }
        } @catch (__unused NSException *e) {}
    }

    @try {
        id adId = [model valueForKey:@"ad_id"];
        if ([adId isKindOfClass:NSString.class] && ((NSString *)adId).length > 0) {
            return YES;
        }
    } @catch (__unused NSException *e) {}

    @try {
        id isSpons = [model valueForKey:@"is_sponsored"];
        if ([isSpons isKindOfClass:NSNumber.class] && [(NSNumber *)isSpons boolValue]) {
            return YES;
        }
    } @catch (__unused NSException *e) {}

    return NO;
}

static BOOL FFBShouldFilterGraphQLModel(id model) {
    if (!model) return NO;

    FocusFBPrefs *prefs = [FocusFBPrefs shared];
    if (!prefs.enabled) return NO;

    BOOL blockAds = prefs.blockAllAds;
    BOOL hideSuggested = prefs.hideSuggestedClutter;
    BOOL hideStoriesReels = prefs.hideStoriesAndInlineReels;

    if (!blockAds && !hideSuggested && !hideStoriesReels) return NO;

    Class cls = object_getClass(model);
    NSString *clsName = NSStringFromClass(cls) ?: @"";

    // IMPORTANTE: non filtrare l'oggetto figlio *SponsoredData* stesso, altrimenti
    // [story sponsoredData] diventerebbe nil e il post padre sembrerebbe organico!
    if ([clsName containsString:@"SponsoredData"] || [clsName hasSuffix:@"AdData"]) {
        return NO;
    }

    // 1. Controllo campo `category` (Feed, Marketplace Edges, Stories)
    SEL catSel = @selector(category);
    if (FFBMethodReturnsObject(cls, catSel)) {
        id rawCat = ((id (*)(id, SEL))objc_msgSend)(model, catSel);
        if ([rawCat isKindOfClass:NSString.class]) {
            NSString *cat = (NSString *)rawCat;
            if (blockAds &&
                ([cat isEqualToString:@"SPONSORED"] ||
                 [cat isEqualToString:@"AD"] ||
                 [cat isEqualToString:@"ADS"] ||
                 [cat isEqualToString:@"MARKETPLACE_ADS"] ||
                 [cat isEqualToString:@"SPONSORED_STORY"])) {
                gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
                return YES;
            }
            if (hideSuggested &&
                ([cat isEqualToString:@"ENGAGEMENT"] ||
                 [cat isEqualToString:@"ENGAGEMENT_QP"] ||
                 [cat isEqualToString:@"PYMK"] ||
                 [cat isEqualToString:@"PYMK_STORY"])) {
                return YES;
            }
            if (hideStoriesReels &&
                ([cat isEqualToString:@"FB_SHORTS"] ||
                 [cat isEqualToString:@"MULTI_FB_STORIES_TRAY"])) {
                return YES;
            }
        }
    }

    // 2. Controllo `sponsoredData` (copre post Feed, Gruppi, Video, Ricerca e unità Marketplace sponsorizzate)
    if (blockAds) {
        SEL sponsSel = @selector(sponsoredData);
        if (FFBMethodReturnsObject(cls, sponsSel)) {
            id sData = ((id (*)(id, SEL))objc_msgSend)(model, sponsSel);
            if (sData != nil && ![sData isKindOfClass:NSNull.class]) {
                gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
                return YES;
            }
        }

        // 3. Controllo `isSponsored` booleano (es. playlist video / item sponsorizzati)
        SEL isSponsSel = @selector(isSponsored);
        if (FFBMethodReturnsBool(cls, isSponsSel)) {
            BOOL flag = ((BOOL (*)(id, SEL))objc_msgSend)(model, isSponsSel);
            if (flag) {
                gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
                return YES;
            }
        }

        // 4. Classi esplicite di unità pubblicitarie (Marketplace, Storie, Video AdBreak)
        if ([clsName containsString:@"MarketplaceFeedAd"] ||
            [clsName containsString:@"MarketplaceAds"] ||
            [clsName containsString:@"MarketplaceAdUnit"] ||
            [clsName containsString:@"MarketplaceAdFeed"] ||
            [clsName containsString:@"MarketplaceBannerAd"] ||
            [clsName containsString:@"MarketplaceSponsored"] ||
            [clsName containsString:@"SponsoredFeedUnit"] ||
            [clsName containsString:@"AdsFeedUnit"] ||
            [clsName containsString:@"InstreamVideoAd"] ||
            [clsName containsString:@"VideoAdBreak"]) {
            gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
            return YES;
        }

        // 5. Bucket pubblicitari nelle Storie (`storyBucketType`)
        SEL bucketSel = NSSelectorFromString(@"storyBucketType");
        if (FFBMethodReturnsObject(cls, bucketSel)) {
            id bucket = ((id (*)(id, SEL))objc_msgSend)(model, bucketSel);
            if ([bucket isKindOfClass:NSString.class]) {
                NSString *bStr = (NSString *)bucket;
                if ([bStr isEqualToString:@"ADS"] ||
                    [bStr isEqualToString:@"AD"] ||
                    [bStr isEqualToString:@"SPONSORED"] ||
                    [bStr isEqualToString:@"SPONSORED_STORY"]) {
                    gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
                    return YES;
                }
                if (hideSuggested && [bStr isEqualToString:@"PYMK_STORY"]) {
                    return YES;
                }
            }
        }

        // 6. Controllo KVC mirato sulle unità Pando di Marketplace / Commerce
        if ([clsName containsString:@"Marketplace"] ||
            [clsName containsString:@"GroupCommerce"] ||
            [clsName containsString:@"CommerceProduct"]) {
            if (FFBIsMarketplaceModelSponsoredViaKVC(model)) {
                gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
                return YES;
            }
        }
    }

    // 7. Rimozione unità suggerite (Gruppi, Pagine, Persone che potresti conoscere, Promo Threads)
    if (hideSuggested) {
        if ([clsName containsString:@"GroupsYouShouldJoin"] ||
            [clsName containsString:@"PagesYouMayLike"] ||
            [clsName containsString:@"PeopleYouMayKnow"]) {
            return YES;
        }
        if ([clsName containsString:@"FeedUnit"] && FFBIsThreadsPromoModel(model, cls)) {
            return YES;
        }
    }

    if (hideStoriesReels && [clsName containsString:@"SingleBucketInlineViewer"]) {
        return YES;
    }

    return NO;
}

static id FFBHook_initWithFBPandoTree(id self, SEL _cmd, void *tree) {
    id model = gOrigInitWithPandoTree ? gOrigInitWithPandoTree(self, _cmd, tree) : nil;
    if (!model) return nil;
    return FFBShouldFilterGraphQLModel(model) ? nil : model;
}

static id FFBHook_initWithFBTree(id self, SEL _cmd, void *tree) {
    id model = gOrigInitWithFBTree ? gOrigInitWithFBTree(self, _cmd, tree) : nil;
    if (!model) return nil;
    return FFBShouldFilterGraphQLModel(model) ? nil : model;
}

// ─────────────────────────────────────────────────────────────────────────────
// LIVELLO 2: JSON GraphQL Edge Pruner (Marketplace / Search / Bloks / Relay)
// Filtra gli edge sponsorizzati direttamente durante NSJSONSerialization
// ─────────────────────────────────────────────────────────────────────────────

static inline BOOL FFBHasNonNullValue(NSDictionary *dict, NSString *key) {
    id v = dict[key];
    return (v != nil && ![v isKindOfClass:NSNull.class]);
}

static inline BOOL FFBIsAdTypenameString(NSString *tn) {
    if (![tn isKindOfClass:NSString.class] || tn.length < 4) return NO;
    return ([tn isEqualToString:@"MarketplaceFeedAdStory"] ||
            [tn isEqualToString:@"MarketplaceAdsFeedUnit"] ||
            [tn isEqualToString:@"MarketplaceAdFeedUnit"] ||
            [tn isEqualToString:@"MarketplaceAdUnit"] ||
            [tn isEqualToString:@"MarketplaceBannerAd"] ||
            [tn isEqualToString:@"SponsoredFeedUnit"] ||
            [tn isEqualToString:@"AdsFeedUnit"] ||
            [tn isEqualToString:@"StoryAd"] ||
            [tn containsString:@"MarketplaceFeedAd"] ||
            [tn containsString:@"MarketplaceSponsored"] ||
            [tn containsString:@"BannerAdUnit"]);
}

static BOOL FFBIsSponsoredJSONDictionaryElement(NSDictionary *dict) {
    if (![dict isKindOfClass:NSDictionary.class]) return NO;

    // Non rimuovere oggetti metadati interni se non sono nodi/edge di lista
    NSString *cat = dict[@"category"];
    if ([cat isKindOfClass:NSString.class] &&
        ([cat isEqualToString:@"SPONSORED"] ||
         [cat isEqualToString:@"ADS"] ||
         [cat isEqualToString:@"MARKETPLACE_ADS"])) {
        return YES;
    }

    if (FFBHasNonNullValue(dict, @"sponsored_data") ||
        FFBHasNonNullValue(dict, @"ad_data") ||
        FFBHasNonNullValue(dict, @"marketplace_ad_data") ||
        FFBHasNonNullValue(dict, @"boosted_marketplace_listing") ||
        FFBHasNonNullValue(dict, @"promoted_listing_info")) {
        return YES;
    }

    id adId = dict[@"ad_id"];
    if ([adId isKindOfClass:NSString.class] && ((NSString *)adId).length > 0) {
        return YES;
    }

    id isSpons = dict[@"is_sponsored"];
    if ([isSpons isKindOfClass:NSNumber.class] && [(NSNumber *)isSpons boolValue]) {
        return YES;
    }

    if (FFBIsAdTypenameString(dict[@"__typename"])) {
        return YES;
    }

    // Controlla eventuale `node` e `node.listing` dentro un edge GraphQL (`{ "node": { ... }, "cursor": "..." }`)
    NSDictionary *node = dict[@"node"];
    if ([node isKindOfClass:NSDictionary.class]) {
        if (FFBHasNonNullValue(node, @"sponsored_data") ||
            FFBHasNonNullValue(node, @"ad_data") ||
            FFBHasNonNullValue(node, @"marketplace_ad_data") ||
            FFBHasNonNullValue(node, @"boosted_marketplace_listing") ||
            FFBHasNonNullValue(node, @"promoted_listing_info")) {
            return YES;
        }
        id nodeAdId = node[@"ad_id"];
        if ([nodeAdId isKindOfClass:NSString.class] && ((NSString *)nodeAdId).length > 0) {
            return YES;
        }
        id nodeSpons = node[@"is_sponsored"];
        if ([nodeSpons isKindOfClass:NSNumber.class] && [(NSNumber *)nodeSpons boolValue]) {
            return YES;
        }
        if (FFBIsAdTypenameString(node[@"__typename"])) {
            return YES;
        }

        NSDictionary *listing = node[@"listing"];
        if ([listing isKindOfClass:NSDictionary.class]) {
            if (FFBHasNonNullValue(listing, @"sponsored_data") ||
                FFBHasNonNullValue(listing, @"ad_data") ||
                FFBHasNonNullValue(listing, @"promoted_listing_info")) {
                return YES;
            }
            id listingSpons = listing[@"is_sponsored"];
            if ([listingSpons isKindOfClass:NSNumber.class] && [(NSNumber *)listingSpons boolValue]) {
                return YES;
            }
        }
    }

    return NO;
}

static id FFBPruneAdsInJSONNode(id obj, BOOL mutableContainers, NSUInteger depth, BOOL *outChanged) {
    if (!obj || depth > 18) return obj;

    if ([obj isKindOfClass:NSArray.class]) {
        NSArray *arr = (NSArray *)obj;
        if (arr.count == 0) return obj;

        BOOL localChanged = NO;
        NSMutableArray *cleaned = nil;

        for (NSUInteger i = 0; i < arr.count; i++) {
            id item = arr[i];
            if ([item isKindOfClass:NSDictionary.class] && FFBIsSponsoredJSONDictionaryElement((NSDictionary *)item)) {
                if (!localChanged) {
                    localChanged = YES;
                    cleaned = [NSMutableArray arrayWithCapacity:arr.count];
                    for (NSUInteger j = 0; j < i; j++) {
                        [cleaned addObject:arr[j]];
                    }
                }
                gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
                continue;
            }

            BOOL childChanged = NO;
            id newItem = FFBPruneAdsInJSONNode(item, mutableContainers, depth + 1, &childChanged);
            if (childChanged && !localChanged) {
                localChanged = YES;
                cleaned = [NSMutableArray arrayWithCapacity:arr.count];
                for (NSUInteger j = 0; j < i; j++) {
                    [cleaned addObject:arr[j]];
                }
            }
            if (localChanged) {
                [cleaned addObject:(newItem ?: item)];
            }
        }

        if (localChanged) {
            if (outChanged) *outChanged = YES;
            return mutableContainers ? cleaned : [cleaned copy];
        }
        return obj;
    }

    if ([obj isKindOfClass:NSDictionary.class]) {
        NSDictionary *dict = (NSDictionary *)obj;
        if (dict.count == 0) return obj;

        BOOL localChanged = NO;
        NSMutableDictionary *mutDict = nil;

        for (id key in dict) {
            id val = dict[key];
            if (![val isKindOfClass:NSArray.class] && ![val isKindOfClass:NSDictionary.class]) {
                continue;
            }
            BOOL childChanged = NO;
            id newVal = FFBPruneAdsInJSONNode(val, mutableContainers, depth + 1, &childChanged);
            if (childChanged) {
                if (!localChanged) {
                    localChanged = YES;
                    mutDict = [dict mutableCopy];
                }
                mutDict[key] = newVal;
            }
        }

        if (localChanged) {
            if (outChanged) *outChanged = YES;
            return mutableContainers ? mutDict : [mutDict copy];
        }
        return obj;
    }

    return obj;
}

static inline BOOL FFBBytesContainASCII(const uint8_t *buf, size_t bufLen, const char *pat, size_t patLen) {
    const uint8_t *p = reinterpret_cast<const uint8_t *>(pat);
    return std::search(buf, buf + bufLen, p, p + patLen) != (buf + bufLen);
}

static BOOL FFBDataMayContainAdsTokens(NSData *data) {
    const uint8_t *bytes = static_cast<const uint8_t *>(data.bytes);
    size_t len = (size_t)data.length;
    if (!bytes || len < 48) return NO;

    // Pre-filtro ultra rapido (~2-4 microsecondi): evita scansione su JSON privi di marker ad
    if (FFBBytesContainASCII(bytes, len, "sponsored", 9)) return YES;
    if (FFBBytesContainASCII(bytes, len, "SPONSORED", 9)) return YES;
    if (FFBBytesContainASCII(bytes, len, "ad_data", 7))   return YES;
    if (FFBBytesContainASCII(bytes, len, "\"ad_id\"", 7)) return YES;
    if (FFBBytesContainASCII(bytes, len, "AdStory", 7))   return YES;
    if (FFBBytesContainASCII(bytes, len, "AdsFeed", 7))   return YES;
    if (FFBBytesContainASCII(bytes, len, "BannerAd", 8))  return YES;
    return NO;
}

static id FFBHook_JSONObjectWithData(id self,
                                     SEL _cmd,
                                     NSData *data,
                                     NSJSONReadingOptions opt,
                                     NSError * __autoreleasing *error) {
    id parsed = gOrigJSONWithData ? gOrigJSONWithData(self, _cmd, data, opt, error) : nil;
    if (!parsed || !data) return parsed;

    FocusFBPrefs *prefs = [FocusFBPrefs shared];
    if (!prefs.enabled || !prefs.blockAllAds) return parsed;
    if (data.length < 64 || data.length > 8 * 1024 * 1024) return parsed;
    if (!FFBDataMayContainAdsTokens(data)) return parsed;

    @try {
        BOOL changed = NO;
        BOOL wantMutable = ((opt & NSJSONReadingMutableContainers) != 0);
        return FFBPruneAdsInJSONNode(parsed, wantMutable, 0, &changed);
    } @catch (__unused NSException *e) {
        return parsed;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// LIVELLO 3: Rete di Sicurezza UI su UICollectionViewCell (Marketplace / Bloks)
// Cattura eventuali card sponsorizzate renderizzate via binario Bloks/ComponentKit
// ─────────────────────────────────────────────────────────────────────────────

static BOOL FFBTextIsStandaloneSponsoredBadge(NSString *raw) {
    if (![raw isKindOfClass:NSString.class] || raw.length < 6 || raw.length > 140) return NO;
    NSCharacterSet *sep = [NSCharacterSet characterSetWithCharactersInString:@"\n\r•·|"];
    NSCharacterSet *ws = [NSCharacterSet whitespaceAndNewlineCharacterSet];

    for (NSString *segment in [raw componentsSeparatedByCharactersInSet:sep]) {
        NSString *t = [[segment stringByTrimmingCharactersInSet:ws] lowercaseString];
        if (t.length < 6 || t.length > 36) continue;
        if ([t isEqualToString:@"sponsorizzato"] ||
            [t isEqualToString:@"sponsored"] ||
            [t isEqualToString:@"sponsorizzato dal venditore"] ||
            [t isEqualToString:@"sponsored by seller"] ||
            [t isEqualToString:@"inserzione sponsorizzata"] ||
            [t isEqualToString:@"annuncio sponsorizzato"] ||
            [t isEqualToString:@"partnership pubblicitaria"] ||
            [t isEqualToString:@"paid partnership"] ||
            [t isEqualToString:@"sponsorisé"] ||
            [t isEqualToString:@"publicidad"] ||
            [t isEqualToString:@"gesponsert"]) {
            return YES;
        }
    }
    return NO;
}

static BOOL FFBSubtreeHasSponsoredDisclosure(UIView *view, NSUInteger depth) {
    if (!view || depth > 6) return NO;

    if ([view isKindOfClass:UILabel.class]) {
        if (FFBTextIsStandaloneSponsoredBadge(((UILabel *)view).text)) return YES;
    }
    NSString *axLbl = view.accessibilityLabel;
    if (axLbl.length > 0 && FFBTextIsStandaloneSponsoredBadge(axLbl)) {
        return YES;
    }
    NSString *axId = view.accessibilityIdentifier;
    if (axId.length > 0) {
        NSString *lowerId = axId.lowercaseString;
        if ([lowerId containsString:@"sponsored_label"] ||
            [lowerId containsString:@"marketplace_ad"] ||
            [lowerId isEqualToString:@"ad_badge"]) {
            return YES;
        }
    }

    for (UIView *sub in view.subviews) {
        if (FFBSubtreeHasSponsoredDisclosure(sub, depth + 1)) return YES;
    }
    return NO;
}

static void FFBResetAdHiddenCellIfNeeded(UICollectionViewCell *cell) {
    if ([objc_getAssociatedObject(cell, &kCellHiddenByAdBlockKey) boolValue]) {
        cell.contentView.hidden = NO;
        cell.alpha = 1.0;
        cell.userInteractionEnabled = YES;
        objc_setAssociatedObject(cell, &kCellHiddenByAdBlockKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(cell, &kCellCountedByAdBlockKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

static void FFBHook_Cell_prepareForReuse(id self, SEL _cmd) {
    if (gOrigCellPrepareReuse) gOrigCellPrepareReuse(self, _cmd);
    FFBResetAdHiddenCellIfNeeded((UICollectionViewCell *)self);
}

static void FFBHook_Cell_layoutSubviews(id self, SEL _cmd) {
    if (gOrigCellLayout) gOrigCellLayout(self, _cmd);
    if (!NSThread.isMainThread) return;

    UICollectionViewCell *cell = (UICollectionViewCell *)self;
    FocusFBPrefs *prefs = [FocusFBPrefs shared];
    if (!prefs.enabled || !prefs.blockAllAds) {
        FFBResetAdHiddenCellIfNeeded(cell);
        return;
    }

    // Applica solo alle celle delle viste Facebook / ComponentKit / Bloks (mai alla nostra UI Impostazioni)
    UIView *parent = cell.superview;
    if (!parent) return;
    NSString *parentCls = NSStringFromClass(object_getClass(parent)) ?: @"";
    NSString *cellCls = NSStringFromClass(object_getClass(cell)) ?: @"";
    if (![parentCls hasPrefix:@"FB"] && ![parentCls hasPrefix:@"CK"] &&
        ![parentCls hasPrefix:@"RCT"] && ![parentCls hasPrefix:@"BK"] &&
        ![cellCls hasPrefix:@"FB"] && ![cellCls hasPrefix:@"CK"] &&
        ![cellCls hasPrefix:@"RCT"] && ![cellCls hasPrefix:@"BK"]) {
        return;
    }

    if (FFBSubtreeHasSponsoredDisclosure(cell.contentView, 0)) {
        cell.contentView.hidden = YES;
        cell.alpha = 0.0;
        cell.userInteractionEnabled = NO;
        objc_setAssociatedObject(cell, &kCellHiddenByAdBlockKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        if (![objc_getAssociatedObject(cell, &kCellCountedByAdBlockKey) boolValue]) {
            objc_setAssociatedObject(cell, &kCellCountedByAdBlockKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            gBlockedAdsCount.fetch_add(1, std::memory_order_relaxed);
        }
    } else {
        FFBResetAdHiddenCellIfNeeded(cell);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Installazione Hook AdBlock (Immediata + Differita per Framework Lazy-Loaded)
// ─────────────────────────────────────────────────────────────────────────────

static void FFBInstallAvailableAdHooksNow(void) {
    Class memModelCls = objc_getClass("FBMemModelObject");
    if (memModelCls) {
        SEL pandoSel = NSSelectorFromString(@"initWithFBPandoTree:");
        if (!gInstalledPandoHook && [memModelCls instancesRespondToSelector:pandoSel]) {
            gInstalledPandoHook = FFBInstallMethodHook(memModelCls,
                                                       pandoSel,
                                                       (IMP)FFBHook_initWithFBPandoTree,
                                                       (IMP *)&gOrigInitWithPandoTree);
        }
        SEL fbTreeSel = NSSelectorFromString(@"initWithFBTree:");
        if (!gInstalledFBTreeHook && [memModelCls instancesRespondToSelector:fbTreeSel]) {
            gInstalledFBTreeHook = FFBInstallMethodHook(memModelCls,
                                                        fbTreeSel,
                                                        (IMP)FFBHook_initWithFBTree,
                                                        (IMP *)&gOrigInitWithFBTree);
        }
    }

    if (!gInstalledJSONHook) {
        Class jsonMetaCls = object_getClass(NSJSONSerialization.class);
        if (jsonMetaCls) {
            gInstalledJSONHook = FFBInstallMethodHook(jsonMetaCls,
                                                      @selector(JSONObjectWithData:options:error:),
                                                      (IMP)FFBHook_JSONObjectWithData,
                                                      (IMP *)&gOrigJSONWithData);
        }
    }

    if (!gInstalledCellHooks) {
        BOOL ok1 = FFBInstallMethodHook(UICollectionViewCell.class,
                                        @selector(layoutSubviews),
                                        (IMP)FFBHook_Cell_layoutSubviews,
                                        (IMP *)&gOrigCellLayout);
        BOOL ok2 = FFBInstallMethodHook(UICollectionViewCell.class,
                                        @selector(prepareForReuse),
                                        (IMP)FFBHook_Cell_prepareForReuse,
                                        (IMP *)&gOrigCellPrepareReuse);
        gInstalledCellHooks = (ok1 && ok2);
    }
}

void FocusFBInstallAdBlocker(void) {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        FFBInstallAvailableAdHooksNow();
        // Riprova anche dopo il caricamento di FBSharedFramework se caricato in differita
        for (NSNumber *delay in @[@0.05, @0.25, @1.0, @3.0]) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay.doubleValue * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                FFBInstallAvailableAdHooksNow();
            });
        }
    });
}
