#!/usr/bin/env bash
set -euo pipefail

# Script per compilazione locale su macOS (senza dipendere da Theos) - FocusFB v2.0
# Uso:
#   ./scripts/build_macos.sh                              -> genera dist/FocusFB.dylib
#   ./scripts/build_macos.sh /percorso/Facebook.ipa       -> genera anche dist/FocusFB_Patched.ipa

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="${PROJECT_DIR}/dist"
INPUT_IPA="${1:-}"
DISPLAY_NAME="${DISPLAY_NAME:-Facebook}"
BUNDLE_ID="${BUNDLE_ID:-com.facebook.Facebook}"

mkdir -p "${DIST_DIR}"

if ! command -v ldid >/dev/null 2>&1; then
  echo "[*] Installazione ldid via Homebrew..."
  brew install ldid-procursus || brew install ldid
fi

SDK_PATH="$(xcrun --sdk iphoneos --show-sdk-path)"
echo "[*] Compilazione FocusFB.dylib v2.0 con Xcode iOS SDK (${SDK_PATH})..."

xcrun --sdk iphoneos clang++ \
  -isysroot "${SDK_PATH}" \
  -target arm64-apple-ios15.0 \
  -dynamiclib \
  -std=gnu++17 \
  -fobjc-arc \
  -fobjc-exceptions \
  -fobjc-call-cxx-cdtors \
  -O2 \
  -Wno-deprecated-declarations \
  -Wno-undeclared-selector \
  -install_name "@rpath/FocusFB.dylib" \
  -I"${PROJECT_DIR}/src" \
  "${PROJECT_DIR}/src/Tweak.mm" \
  "${PROJECT_DIR}/src/FocusFBPrefs.mm" \
  "${PROJECT_DIR}/src/FocusFBSideloadFix.mm" \
  "${PROJECT_DIR}/src/FocusFBTabManager.mm" \
  "${PROJECT_DIR}/src/FocusFBSettingsViewController.mm" \
  "${PROJECT_DIR}/src/FocusFBLockManager.mm" \
  -lobjc \
  -framework Foundation \
  -framework CoreFoundation \
  -framework UIKit \
  -framework QuartzCore \
  -framework CoreGraphics \
  -framework Security \
  -framework AVFoundation \
  -framework CoreImage \
  -weak_framework CoreNFC \
  -o "${DIST_DIR}/FocusFB.dylib"

ldid -S "${DIST_DIR}/FocusFB.dylib"
python3 "${PROJECT_DIR}/scripts/verify_dylib.py" "${DIST_DIR}/FocusFB.dylib"

if [[ -n "${INPUT_IPA}" ]]; then
  if ! command -v cyan >/dev/null 2>&1; then
    echo "[*] Installazione cyan (pyzule-rw)..."
    pipx install --force https://github.com/asdfzxcvbn/pyzule-rw/archive/main.zip
  fi
  MERGE_PLIST="${DIST_DIR}/focusfb_info_merge.plist"
  cat > "${MERGE_PLIST}" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>NFCReaderUsageDescription</key>
  <string>Scansione chiave NFC per sbloccare FocusFB</string>
</dict>
</plist>
EOF
  echo "[*] Iniezione di FocusFB.dylib v2.0 nell'IPA..."
  cyan -i "${INPUT_IPA}" \
       -o "${DIST_DIR}/FocusFB_Patched.ipa" \
       -u -w -e -q -s --overwrite \
       -n "${DISPLAY_NAME}" \
       -b "${BUNDLE_ID}" \
       -l "${MERGE_PLIST}" \
       -f "${DIST_DIR}/FocusFB.dylib"
  rm -f "${MERGE_PLIST}"
  echo "[OK] IPA generata in: ${DIST_DIR}/FocusFB_Patched.ipa"
fi

echo "[OK] Build completata in: ${DIST_DIR}"
ls -lh "${DIST_DIR}"
